export const ENV = {
  production: false,
  isDebugMode: true,
  baseUrl:'http://localhost:8181/auth'
};