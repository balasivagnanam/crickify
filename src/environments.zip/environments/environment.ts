export const ENV = {
  production: true,
  isDebugMode: false,
  baseUrl:'https://crickify.herokuapp.com'
};